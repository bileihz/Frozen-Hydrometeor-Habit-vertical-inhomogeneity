frq_ext.dat: Bulk extinction coefficient against frequencies
4 record:
	thin plate at 203K for 10 frequencies 
	thin plate at 273K for 10 frequencies
	dendrite at 203K for 10 frequencies
	dendrite at 273K for 10 frequencies

frq = 10.65,18.7,23.8,36.5,50.3,57.29,89.0,118.75,150,183.31 [GHZ]

frq_ssa.dat: Bulk SSA coefficient against frequencies
4 record:
	thin plate at 203K for 10 frequencies 
	thin plate at 273K for 10 frequencies
	dendrite at 203K for 10 frequencies
	dendrite at 273K for 10 frequencies

swc = 10 ** (0.01 * (iwc - 300)) [g/m^3]

frq = 10.65,18.7,23.8,36.5,50.3,57.29,89.0,118.75,150,183.31 [GHZ]

frq_asm.dat: Bulk asymmetry coefficient against frequencies
4 record:
	thin plate at 203K for 10 frequencies 
	thin plate at 273K for 10 frequencies
	dendrite at 203K for 10 frequencies
	dendrite at 273K for 10 frequencies

swc = 10 ** (0.01 * (iwc - 300)) [g/m^3]

frq = 10.65,18.7,23.8,36.5,50.3,57.29,89.0,118.75,150,183.31 [GHZ]
