swc_ext.dat: Bulk extinction coefficient against snow water content
4 record:
	thin plate at 203K for 401 water content 
	thin plate at 273K for 401 water content
	dendrite at 203K for 401 water content
	dendrite at 273K for 401 water content

swc = 10 ** (0.01 * (iwc - 300)) [g/m^3]

swc_ssa.dat: Bulk SSA coefficient against snow water content
4 record:
	thin plate at 203K for 401 water content 
	thin plate at 273K for 401 water content
	dendrite at 203K for 401 water content
	dendrite at 273K for 401 water content

swc = 10 ** (0.01 * (iwc - 300)) [g/m^3]

swc_asm.dat: Bulk asymmetry coefficient against snow water content
4 record:
	thin plate at 203K for 401 water content 
	thin plate at 273K for 401 water content
	dendrite at 203K for 401 water content
	dendrite at 273K for 401 water content

swc = 10 ** (0.01 * (iwc - 300)) [g/m^3]
