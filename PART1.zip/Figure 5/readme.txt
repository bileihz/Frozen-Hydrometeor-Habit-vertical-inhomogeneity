Description: The standard profile of Typhoon Feiyan

6 record:

1. cc profile at 30 RTTOV-SCATT layers
2. ciw profile at 30 RTTOV-SCATT layers
3. clw profile at 30 RTTOV-SCATT layers
4. rain profile at 30 RTTOV-SCATT layers
5. sp profile at 30 RTTOV-SCATT layers
6. gh profile at 30 RTTOV-SCATT layers

RTTOV-SCATT layers (layer center):
10 ,20 ,30 ,50 ,70 ,100,125,150,175,200,
225,250,275,300,350,400,450,500,550,600,
650,700,750,800,850,900,925,950,975,1000
[hPa]
