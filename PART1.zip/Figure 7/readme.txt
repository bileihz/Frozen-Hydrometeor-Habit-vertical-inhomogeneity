[A]. ovb_mwri_b.dat:

The simulated TOA BT of 4 FHHVI scenarios of a MWRI swath within GRAPES RMFS region
[by RTTOV-SVATT]

totally 37744 profiles

dimension: 

1. 4 scenario: A.Thin plate B.Dendrite C. Thin plate / Dendrite D. Dendrite / Thin plate

2. 37744 profiles

3. 10 channels:  
1	10.65GHZ 	V
2	10.65GHZ	H
3	18.7GHZ 	V
4	18.7GHZ		H
5	23.8GHZ		V
6	23.8GHZ		H
7	36.5GHZ		V
8	36.5GHZ		H
9	89.0GHZ		V
10	89.0GHZ		H


[B]. ovb_mwri_b.dat:

The observed TOA BT of an FY3D/MWRI swath within GRAPES RMFS region 

totally 37744 profiles

dimension: 

1. 37744 profiles

2. 10 channels:  
1	10.65GHZ 	V
2	10.65GHZ	H
3	18.7GHZ 	V
4	18.7GHZ		H
5	23.8GHZ		V
6	23.8GHZ		H
7	36.5GHZ		V
8	36.5GHZ		H
9	89.0GHZ		V
10	89.0GHZ		H

[C]. ovb_mwri_Geo.dat:

The Geolocation an FY3D/MWRI FOVs within GRAPES RMFS region 

totally 37744 profiles

dimension: 

1. dataset: lat / lon

2. 37744 profiles:

