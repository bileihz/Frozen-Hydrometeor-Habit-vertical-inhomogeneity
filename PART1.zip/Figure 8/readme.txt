[A]. ovb_mwhs2_b.dat:

The simulated TOA BT of 4 FHHVI scenarios of a MWHS2 swath within GRAPES RMFS region
[by RTTOV-SVATT]

totally 58851 profiles

dimension: 

1. 4 scenarios: A.Thin plate B.Dendrite C. Thin plate / Dendrite D. Dendrite / Thin plate

2. 58851 profiles

3. 11 hydrometeor sensitive channels:  
1	118.75±0.8GHZ
2	118.75±1.1GHZ
3	118.75±2.5GHZ
4	118.75±3.0GHZ
5	118.75±5.0GHZ
6	150.0GHZ
7	183.31±1.0GHZ
8	183.31±1.8GHZ
9	183.31±3.0GHZ
10	183.31±4.5GHZ
11	183.31±7.0GHZ


[B]. ovb_mwhs2_b.dat:

The observed TOA BT of an FY3D/MWHS2 swath within GRAPES RMFS region 

totally 58851 profiles

dimension: 

1. 58851 profiles

3. 11 hydrometeor sensitive channels:  
1	118.75±0.8GHZ
2	118.75±1.1GHZ
3	118.75±2.5GHZ
4	118.75±3.0GHZ
5	118.75±5.0GHZ
6	150.0GHZ
7	183.31±1.0GHZ
8	183.31±1.8GHZ
9	183.31±3.0GHZ
10	183.31±4.5GHZ
11	183.31±7.0GHZ


[C]. ovb_mwhs2_Geo.dat:

The Geolocation an FY3D/MWHS2 FOVs within GRAPES RMFS region 

totally 58851 profiles

dimension: 

1. dataset: lat / lon

2. 58851 profiles:

