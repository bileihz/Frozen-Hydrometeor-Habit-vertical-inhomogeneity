histogram_fit_mwhs2.dat

description: The histogram fit penalty h of each channels of each FHHVI scenarios 

dimensions: 


1. 4 FHHVI scenarios

1. Thin plate
2. Dendrite
3. Thin plate / Dendrite
4. Dendrite / Thin plate


2. 11 channels of MWHS2

1	118.75±0.8GHZ
2	118.75±1.1GHZ
3	118.75±2.5GHZ
4	118.75±3.0GHZ
5	118.75±5.0GHZ
6	150.0GHZ
7	183.31±1.0GHZ
8	183.31±1.8GHZ
9	183.31±3.0GHZ
10	183.31±4.5GHZ
11	183.31±7.0GHZ