fit_histogram_mwhs2.dat

description: The number of FOVs in observation and simulation histogram bins

dimensions: 

1. 11 channels of MWHS2

1	118.75±0.8GHZ
2	118.75±1.1GHZ
3	118.75±2.5GHZ
4	118.75±3.0GHZ
5	118.75±5.0GHZ
6	150.0GHZ
7	183.31±1.0GHZ
8	183.31±1.8GHZ
9	183.31±3.0GHZ
10	183.31±4.5GHZ
11	183.31±7.0GHZ

2. 4 FHHVI scenarios

1. Thin plate
2. Dendrite
3. Thin plate / Dendrite
4. Dendrite / Thin plate

Totally 44 records, each record is consisted of 3 subrecord:

a. bin center (binsize=2.5K)
b. numbers in observation bin
c. numbers in simulation bin

 