map_FG_mwhs2.dat:

Descriptions: The mean FG departure on a map for FHHVI scenarios and channels on MWHS2

on a 2x2 lat lon Geo grid

Dimension:

1. 11 channels of MWHS2

1	118.75±0.8GHZ
2	118.75±1.1GHZ
3	118.75±2.5GHZ
4	118.75±3.0GHZ
5	118.75±5.0GHZ
6	150.0GHZ
7	183.31±1.0GHZ
8	183.31±1.8GHZ
9	183.31±3.0GHZ
10	183.31±4.5GHZ
11	183.31±7.0GHZ

2. 4 FHHVI scenarios

1. Thin plate
2. Dendrite
3. Thin plate / Dendrite
4. Dendrite / Thin plate

3. lon
121.  123.  125.  127.  129.  131.  133.  135.  137.  139.  141.  143. 144.5

4. lat
16.  18.  20.  22.  24.  26.  28.  29.5
